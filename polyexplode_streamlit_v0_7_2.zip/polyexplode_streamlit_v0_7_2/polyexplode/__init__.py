"""PolyExplode Streamlit core package."""

__version__ = "0.7.2"
